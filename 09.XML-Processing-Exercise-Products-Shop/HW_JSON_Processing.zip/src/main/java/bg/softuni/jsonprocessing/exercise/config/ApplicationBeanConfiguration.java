package bg.softuni.jsonprocessing.exercise.config;

import bg.softuni.jsonprocessing.exercise.model.dto.exportdtos.CategoryViewDto;
import bg.softuni.jsonprocessing.exercise.model.dto.exportdtos.ProductWithoutBuyerDto;
import bg.softuni.jsonprocessing.exercise.model.entity.Category;
import bg.softuni.jsonprocessing.exercise.model.entity.Product;
import bg.softuni.jsonprocessing.exercise.model.entity.User;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.modelmapper.Converter;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.modelmapper.spi.MappingContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.math.BigDecimal;
import java.util.Collection;

@Configuration
public class ApplicationBeanConfiguration {

    @Bean
    public ModelMapper modelMapper() {
        ModelMapper modelMapper = new ModelMapper();

        Converter<User, String> converter = new Converter<User, String>() {
            @Override
            public String convert(MappingContext<User, String> mappingContext) {
                return mappingContext.getSource() == null
                        ? null
                        : mappingContext.getSource().getFirstName() == null
                        ? mappingContext.getSource().getLastName()
                        : String.format("%s %s",
                        mappingContext.getSource().getFirstName(),
                        mappingContext.getSource().getLastName());
            }
        };

        modelMapper.addConverter(converter);

//        modelMapper.addMappings(new PropertyMap<Category, CategoryViewDto>() {
//            @Override
//            protected void configure() {
//                map().setCategory(source.getName());
//                map().setProductsCount(
//                        source.getProducts() == null ? 0 :
//                                source.getProducts().size());
//                map().setAveragePrice(
//                        source.getProducts() == null ? BigDecimal.valueOf(0) :
//                                getTotalRevenue(source)
//                                        .divide(BigDecimal.valueOf(source.getProducts().size())));
//                map().setTotalRevenue(
//                        source.getProducts() == null ? BigDecimal.valueOf(0) :
//                                getTotalRevenue(source));
//            }
//
//
//        });

        return modelMapper;
    }

    @Bean
    public Gson gson() {
        return new GsonBuilder()
                .excludeFieldsWithoutExposeAnnotation()
                .setPrettyPrinting()
                .create();
    }


    private static BigDecimal getTotalRevenue(Category category) {
        return category
                .getProducts()
                .stream()
                .map(Product::getPrice)
                .reduce(BigDecimal::add)
                .orElse(BigDecimal.valueOf(0));
    }
}
