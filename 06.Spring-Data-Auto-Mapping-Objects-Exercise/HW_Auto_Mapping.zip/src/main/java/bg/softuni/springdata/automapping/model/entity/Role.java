package bg.softuni.springdata.automapping.model.entity;

public enum Role {
    USER, ADMIN
}
