package bg.softuni.springdata.intro.model.entity;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
