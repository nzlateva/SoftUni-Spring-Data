package entities.paymentsystem;

public enum CardType {
    GOLD, SILVER
}
