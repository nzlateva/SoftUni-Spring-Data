package entities.football.enums;

public enum PositionDescription {
    GOAL_KEEPER, DEFENDER
}
