package entities.football.enums;

public enum CompetitionName {
    LOCAL, NATIONAL, INTERNATIONAL
}
