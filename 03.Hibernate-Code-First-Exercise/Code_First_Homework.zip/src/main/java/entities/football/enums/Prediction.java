package entities.football.enums;

public enum Prediction {
    HOME_TEAM_WIN, DRAW_GAME, AWAY_TEAM_WIN
}
