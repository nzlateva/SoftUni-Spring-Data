package entities.football.enums;

public enum RoundName {
    GROUPS, LEAGUE, EIGHT_FINAL, QUARTERFINALS, SEMI_FINAL, FINAL
}
